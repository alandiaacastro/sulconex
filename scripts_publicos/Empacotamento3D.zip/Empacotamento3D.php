<?php
/**
* Autor: Alan Daniel dias castro 
 * Empacotamento3D.php
 */

class Empacotamento3D
{
    private $W; // Largura do Contêiner (X)
    private $D; // Profundidade/Comprimento do Contêiner (Y)
    private $H; // Altura do Contêiner (Z)
    private $items = [];          // Itens originais (instâncias individuais)
    private $placedItems = [];    // Itens posicionados
    
    // Opções de empacotamento
    private $sortByVolumeDesc = true; 
    private $allow_stacking = true; 
    private $allow_rotation = true; 
    private $useMergedCoilPattern = false; // Controla o padrão "V" inicial

    private $log = []; 
    private static $itemCounter = 0; 
    private static $itemGroupCounter = 0; // Contador para grupos de itens
    private $lastPlacedItemDetails = null; 

    public function __construct(float $W, float $D, float $H)
    {
        $this->W = $W;
        $this->D = $D;
        $this->H = $H;
        self::$itemCounter = 0; 
        self::$itemGroupCounter = 0; 
        $this->addLog("INFO", "Contêiner (geral) inicializado: W={$W}, D={$D}, H={$H}.");
    }

    private function addLog(string $type, string $msg)
    {
        $timestamp = date('Y-m-d H:i:s');
        $this->log[] = "[{$timestamp}] {$type}: {$msg}";
    }

    public function getLogFormatted(): array
    {
        return $this->log;
    }

    public function addItem(string $tipo, int $q, float $w, float $d, float $h, float $peso_bruto)
    {
        if (!in_array($tipo, ['caixa','bobina'], true)) {
            $this->addLog("WARNING", "Tipo inválido: {$tipo}. Item ignorado.");
            return;
        }
        if ($q < 1 || $w <= 1e-6 || $h <= 1e-6 || ($tipo === 'caixa' && $d <= 1e-6) || $peso_bruto < -1e-6) { 
            $this->addLog("WARNING", "Parâmetros inválidos para item [$tipo]: q={$q}, w={$w}, d={$d}, h={$h}, peso={$peso_bruto}. Item ignorado.");
            return;
        }
        
        self::$itemGroupCounter++; 
        $currentGroupId = self::$itemGroupCounter;

        for ($i = 0; $i < $q; $i++) {
            self::$itemCounter++;
            $this->items[] = [
                'id_original_instance' => self::$itemCounter,
                'id_grupo_item' => $currentGroupId, // Atribui o ID do grupo
                'tipo' => $tipo,
                'w_orig' => $w,
                'd_orig' => $d, 
                'h_orig' => $h,
                'peso_bruto_orig' => $peso_bruto,
            ];
        }
        $this->addLog("INFO", "Adicionado {$q}× {$tipo} (GrupoID: {$currentGroupId}, Base: {$w}×{$d}×{$h}, Peso: {$peso_bruto}kg). Inst. IDs: " . (self::$itemCounter - $q + 1) . " a " . self::$itemCounter);
    }

    public function setSortByVolumeDesc(bool $flag) { $this->sortByVolumeDesc = $flag; $logMsg = $flag ? "Ordenação por volume decrescente ATIVADA." : "Ordenação por volume decrescente DESATIVADA (ordem de entrada)."; $this->addLog("INFO", $logMsg); }
    public function setAllowStacking(bool $flag) { $this->allow_stacking = $flag; $logMsg = $flag ? "Empilhamento de itens PERMITIDO." : "Empilhamento de itens DESATIVADO (somente no piso)."; $this->addLog("INFO", $logMsg); }
    public function setAllowRotation(bool $flag) { $this->allow_rotation = $flag; $logMsg = $flag ? "Rotação de caixas PERMITIDA." : "Rotação de caixas DESATIVADA (usar orientação original)."; $this->addLog("INFO", $logMsg); }
    public function setUseMergedCoilPattern(bool $flag) { $this->useMergedCoilPattern = $flag; $logMsg = $flag ? "Padrão 'V' Inicial/Linha para Bobinas ATIVADO." : "Padrão 'V' Inicial/Linha para Bobinas DESATIVADO."; $this->addLog("INFO", $logMsg); }
    
    private function getItemOrientations(array $item_instance): array {
        $tipoOriginal = $item_instance['tipo'];
        $w = $item_instance['w_orig']; $d = $item_instance['d_orig']; $h = $item_instance['h_orig'];
        $peso_bruto_orig = $item_instance['peso_bruto_orig']; $id_original_instance = $item_instance['id_original_instance'];
        $id_grupo_item = $item_instance['id_grupo_item']; 
        $orientations = [];
        if ($tipoOriginal === 'bobina') {
            $orientations[] = ['w' => $w, 'd' => $w, 'h' => $h, 'tipo_orientacao' => 'bobina', 
                                'id_original_instance' => $id_original_instance, 
                                'id_grupo_item' => $id_grupo_item, 
                                'peso_bruto_orig' => $peso_bruto_orig];
            return $orientations;
        }
        if (!$this->allow_rotation) {
            $orientations[] = ['w' => $w, 'd' => $d, 'h' => $h, 'tipo_orientacao' => 'caixa',
                                'id_original_instance' => $id_original_instance,
                                'id_grupo_item' => $id_grupo_item, 
                                'peso_bruto_orig' => $peso_bruto_orig];
            return $orientations;
        }
        $dims_permutations = [ [$w, $d, $h], [$d, $w, $h], [$w, $h, $d], [$h, $w, $d], [$d, $h, $w], [$h, $d, $w] ];
        $seen_rotations_keys = [];
        foreach ($dims_permutations as $p_dims) {
            list($pw, $pd, $ph) = $p_dims;
            if ($pw <= 1e-6 || $pd <= 1e-6 || $ph <= 1e-6) continue; 
            $key_str = number_format($pw, 6) . '-' . number_format($pd, 6) . '-' . number_format($ph, 6);
            if (!isset($seen_rotations_keys[$key_str])) {
                 $orientations[] = ['w' => $pw, 'd' => $pd, 'h' => $ph, 'tipo_orientacao' => 'caixa',
                                     'id_original_instance' => $id_original_instance,
                                     'id_grupo_item' => $id_grupo_item, 
                                     'peso_bruto_orig' => $peso_bruto_orig];
                 $seen_rotations_keys[$key_str] = true;
            }
        }
        return $orientations;
    }

    public function generatePacking() {
        $this->placedItems = []; $this->lastPlacedItemDetails = null; $packedCount = 0;
        $totalItemsToPackInitially = count($this->items); 
        $this->addLog("INFO", "Iniciando empacotamento... Empilhar: " . ($this->allow_stacking ? "ON" : "OFF") .
            ", Rotacionar: " . ($this->allow_rotation ? "ON" : "OFF") .
            ", Ordenar por Volume: " . ($this->sortByVolumeDesc ? "ON" : "OFF") .
            ", Padrão 'V' Inicial/Linha Bobinas: " . ($this->useMergedCoilPattern ? "ON" : "OFF"));
        $W_cont = $this->W; $D_cont = $this->D; $H_cont = $this->H;
        $itemsInputList = $this->items; 
        if (empty($itemsInputList)) { $this->addLog("WARNING", "Nenhum item para empacotar."); return; }
        $totalItemsToPackEffectivelyConsidered = 0;

        if ($this->useMergedCoilPattern) {
            $firstItemInstance = null; $itemsForSpecificPattern = []; $otherItems = []; 
            $refDiametro = null; $refAltura = null; $firstCoilFoundForPattern = false;
            if (!empty($itemsInputList)) {
                foreach ($itemsInputList as $itemInstance) {
                    if (!$firstCoilFoundForPattern && $itemInstance['tipo'] === 'bobina') {
                        $firstItemInstance = $itemInstance; $refDiametro = $firstItemInstance['w_orig'];
                        $refAltura = $firstItemInstance['h_orig']; $firstCoilFoundForPattern = true;
                    }
                    if ($firstCoilFoundForPattern && $itemInstance['tipo'] === 'bobina' &&
                        abs($itemInstance['w_orig'] - $refDiametro) < 1e-6 && abs($itemInstance['h_orig'] - $refAltura) < 1e-6) {
                        $itemsForSpecificPattern[] = $itemInstance;
                    } else {
                        if ($firstCoilFoundForPattern && $itemInstance['tipo'] === 'bobina') {
                             $this->addLog("INFO", "Bobina Inst.ID " . $itemInstance['id_original_instance'] . " com dimensões diferentes do padrão será tratada com algoritmo padrão.");
                        }
                        $otherItems[] = $itemInstance;
                    }
                }
            }
            $quantityForSpecificPattern = count($itemsForSpecificPattern);
            if ($firstItemInstance && $firstItemInstance['tipo'] === 'bobina' && $quantityForSpecificPattern > 0) {
                $this->addLog("INFO", "Aplicando padrão 'V' Inicial/Linha para Bobinas. Ref: D={$refDiametro}, H={$refAltura}, Qtd={$quantityForSpecificPattern}");
                list($countFromPattern, $placedInPattern) = $this->_packCoilsWithVStartAndGridPattern(
                    $W_cont, $D_cont, $H_cont, $refDiametro, $refAltura, $quantityForSpecificPattern, $itemsForSpecificPattern
                );
                $this->placedItems = array_merge($this->placedItems, $placedInPattern);
                $packedCount += $countFromPattern;
                $totalItemsToPackEffectivelyConsidered += $quantityForSpecificPattern;
                if (!empty($otherItems)) {
                    $this->addLog("INFO", "Tentando empacotar " . count($otherItems) . " itens restantes com algoritmo padrão.");
                     list($countStd, $placedStd) = $this->_standardPackingAlgorithm($W_cont, $D_cont, $H_cont, $otherItems, $this->placedItems); 
                     $this->placedItems = array_merge($this->placedItems, $placedStd);
                     $packedCount += $countStd; $totalItemsToPackEffectivelyConsidered += count($otherItems);
                }
            } else {
                if ($this->useMergedCoilPattern) { $this->addLog("WARNING", "Padrão 'V' Inicial/Linha não aplicado. Revertendo para padrão."); }
                list($packedCount, $this->placedItems) = $this->_standardPackingAlgorithm($W_cont, $D_cont, $H_cont, $itemsInputList, []);
                $totalItemsToPackEffectivelyConsidered = $totalItemsToPackInitially;
            }
        } else {
            list($packedCount, $this->placedItems) = $this->_standardPackingAlgorithm($W_cont, $D_cont, $H_cont, $itemsInputList, []);
            $totalItemsToPackEffectivelyConsidered = $totalItemsToPackInitially;
        }
        $this->addLog("INFO", "Empacotamento concluído: ". $packedCount ."/{$totalItemsToPackEffectivelyConsidered} instâncias consideradas foram posicionadas.");
        if ($totalItemsToPackInitially != $totalItemsToPackEffectivelyConsidered) { $this->addLog("INFO", "Total de instâncias de entrada original: {$totalItemsToPackInitially}."); }
        $this->addLog("INFO", "Volume do contêiner: " . number_format($this->W * $this->D * $this->H, 3) . " m³.");
        $this->addLog("INFO", "Volume dos itens posicionados: " . number_format($this->getPlacedItemsVolume(), 3) . " m³.");
        $this->addLog("INFO", "Utilização do volume: " . number_format($this->getVolumeUtilization(), 2) . "%.");
        $this->addLog("INFO", "Peso bruto total dos itens posicionados: " . number_format($this->getPlacedItemsWeight(), 2) . " kg.");
    }
    
    private function _packCoilsWithVStartAndGridPattern(float $W_cont, float $D_cont, float $H_cont, float $diametro, float $alt_bobina, int $quantidadeDesejada, array $coilInstancesToPlace): array
    {
        $this->addLog("DEBUG", "_packCoilsWithVStartAndGridPattern: Cont(W={$W_cont}, D={$D_cont}, H={$H_cont}), Bobina(Diam={$diametro}, Alt={$alt_bobina}), QtdDesejada={$quantidadeDesejada}");
        $placedItemsArray = []; $packedCount = 0; $instanceIdx = 0; 
        if ($diametro <= 1e-6 || $alt_bobina <= 1e-6) { $this->addLog("ERROR", "Padrão V/Linha: Dimensões da bobina inválidas."); return [0,[]]; }
        $pilhas = intval($H_cont / $alt_bobina);
        if ($pilhas == 0) { $this->addLog("WARNING", "Padrão V/Linha: Altura do contêiner não permite nenhuma pilha."); return [0,[]]; }
        $this->addLog("DEBUG", "Padrão V/Linha: Máximo de camadas: {$pilhas}.");

        $R = $diametro / 2; $z_center_camada_base = $alt_bobina / 2;
        $centros_na_base_colocados = []; $todas_bobinas_base_para_empilhar = []; 

        $checkCollisionWithExistingCenters = function($x_new, $y_new, $existing_centers) use ($diametro) {
            foreach ($existing_centers as $existing_c) {
                if (pow($x_new - $existing_c[0], 2) + pow($y_new - $existing_c[1], 2) < pow($diametro - 1e-5, 2)) return true;
            } return false;
        };
            
        $addBobinaToArrayAndTrack = function($x_c, $y_c, $z_c) use (
            $diametro, $alt_bobina, &$coilInstancesToPlace, &$instanceIdx, $W_cont, $D_cont, $H_cont, $quantidadeDesejada, 
            &$packedCount, &$placedItemsArray, &$todas_bobinas_base_para_empilhar, &$centros_na_base_colocados, 
            $R, $z_center_camada_base, $checkCollisionWithExistingCenters
        ) : ?array { 
            if ($instanceIdx >= count($coilInstancesToPlace) || $packedCount >= $quantidadeDesejada) return null;
            if (abs($z_c - $z_center_camada_base) < 1e-5 && $checkCollisionWithExistingCenters($x_c, $y_c, $centros_na_base_colocados)) return null; 
            $x_corner = $x_c - $R; $y_corner = $y_c - $R; $z_corner = $z_c - ($alt_bobina / 2);
            if ($x_corner >= -1e-6 && ($x_corner + $diametro) <= $W_cont + 1e-6 &&
                $y_corner >= -1e-6 && ($y_corner + $diametro) <= $D_cont + 1e-6 &&
                $z_corner >= -1e-6 && ($z_corner + $alt_bobina) <= $H_cont + 1e-6) {
                $currentInstance = $coilInstancesToPlace[$instanceIdx];
                $bobinaData = [
                    'x' => $x_corner, 'y' => $y_corner, 'z' => $z_corner, 
                    'w' => $diametro, 'd' => $diametro, 'h' => $alt_bobina, 
                    'tipo' => 'bobina', 
                    'id_original_instance' => $currentInstance['id_original_instance'],
                    'id_grupo_item' => $currentInstance['id_grupo_item'], 
                    'peso_bruto' => $currentInstance['peso_bruto_orig']
                ];
                $placedItemsArray[] = $bobinaData;
                if (abs($z_c - $z_center_camada_base) < 1e-5) {
                    $centros_na_base_colocados[] = [$x_c, $y_c]; $todas_bobinas_base_para_empilhar[] = $bobinaData; 
                }
                $packedCount++; $instanceIdx++; return $bobinaData;
            } return null;
        };

        $this->addLog("DEBUG", "Padrão V/Linha: Iniciando padrão 'V' na base. R={$R}");
        $v_pattern_placed_count = 0;

        $y_base_v = $R;
        $y_ponta_v = $R + $diametro * sqrt(3) / 2; 

        $x_ponta_v = $W_cont / 2;
        $x_base_esq_v = $W_cont / 2 - $R;
        $x_base_dir_v = $W_cont / 2 + $R;

        if ($W_cont >= 2 * $diametro - 1e-6) { 
            if ($addBobinaToArrayAndTrack($x_base_esq_v, $y_base_v, $z_center_camada_base)) {
                $this->addLog("DEBUG", "Padrão V: Colocada Bobina Base Esquerda em ({$x_base_esq_v}, {$y_base_v})");
                $v_pattern_placed_count++;
            }
            if ($addBobinaToArrayAndTrack($x_base_dir_v, $y_base_v, $z_center_camada_base)) {
                $this->addLog("DEBUG", "Padrão V: Colocada Bobina Base Direita em ({$x_base_dir_v}, {$y_base_v})");
                $v_pattern_placed_count++;
            }
        } elseif ($W_cont >= $diametro - 1e-6) { 
            if ($addBobinaToArrayAndTrack($W_cont / 2, $y_base_v, $z_center_camada_base)) {
                $this->addLog("DEBUG", "Padrão V: Colocada Bobina Base Central (largura insuficiente para 2) em (".($W_cont/2).", {$y_base_v})");
                $v_pattern_placed_count++;
            }
        }

        if ($D_cont >= ($y_ponta_v + $R - 1e-6)) {
            if ($addBobinaToArrayAndTrack($x_ponta_v, $y_ponta_v, $z_center_camada_base)) {
                $this->addLog("DEBUG", "Padrão V: Colocada Bobina Ponta V em (". $x_ponta_v .", ". $y_ponta_v .")");
                $v_pattern_placed_count++;
            }
        }
        $this->addLog("DEBUG", "Padrão V/Linha: Padrão V inicial concluiu com ". $v_pattern_placed_count ." bobinas. Total Packed: ". $packedCount ."");
                
        $this->addLog("DEBUG", "Padrão V/Linha: Iniciando preenchimento EM LINHA na base.");
        for ($y_grid_center = $R; $y_grid_center <= ($D_cont - $R) + 1e-6; $y_grid_center += $diametro) {
            if ($packedCount >= $quantidadeDesejada) break;
            for ($x_grid_center = $R; $x_grid_center <= ($W_cont - $R) + 1e-6; $x_grid_center += $diametro) {
                if ($packedCount >= $quantidadeDesejada) break;
                $addBobinaToArrayAndTrack($x_grid_center, $y_grid_center, $z_center_camada_base); 
            } if ($packedCount >= $quantidadeDesejada) break;
        }
        $this->addLog("DEBUG", "Padrão V/Linha: Preenchimento EM LINHA base concluiu. Total na base: " . count($todas_bobinas_base_para_empilhar) . ". Total Packed: ". $packedCount ."");
        
        $this->addLog("DEBUG", "Padrão V/Linha: Iniciando empilhamento SOBRE TODA A BASE. Pilhas: " . ($pilhas - 1));
        if ($pilhas > 1 && !empty($todas_bobinas_base_para_empilhar)) { 
            $unique_base_objects_for_stacking = []; $seen_base_coords_for_stack = [];
            foreach($todas_bobinas_base_para_empilhar as $base_o) {
                $key = number_format($base_o['x'],3) . "_" . number_format($base_o['y'],3);
                if(!isset($seen_base_coords_for_stack[$key])) { $unique_base_objects_for_stacking[] = $base_o; $seen_base_coords_for_stack[$key] = true; }
            }
            $this->addLog("DEBUG", "Padrão V/Linha: ".count($unique_base_objects_for_stacking)." posições base ÚNICAS para empilhamento.");
            for ($p = 1; $p < $pilhas; $p++) { 
                if ($packedCount >= $quantidadeDesejada) break;
                $z_pilha_center = ($p * $alt_bobina) + ($alt_bobina / 2); 
                $this->addLog("DEBUG", "Empilhando camada ".($p+1)." em Z_center={$z_pilha_center}");
                foreach ($unique_base_objects_for_stacking as $base_obj_to_stack_on) { 
                    if ($packedCount >= $quantidadeDesejada) break;
                    $x_base_center = $base_obj_to_stack_on['x'] + $R; $y_base_center = $base_obj_to_stack_on['y'] + $R; 
                    $addBobinaToArrayAndTrack($x_base_center, $y_base_center, $z_pilha_center); 
                }
            }
        }
        $this->addLog("DEBUG", "Padrão V/Linha: Empilhamento vertical concluiu. Total empacotado: ". $packedCount ."");
        
        if (!empty($placedItemsArray)) {
             $placedItemsArray = $this->_alignLoadCenter($placedItemsArray, $W_cont, $D_cont, $diametro, false); 
             $this->addLog("INFO", "Padrão V/Linha: Carga de bobinas ALINHADA AO CENTRO (X e Y).");
        }
        return [$packedCount, $placedItemsArray];
    }

    private function _alignLoadCenter(array $items, float $containerW, float $containerD, float $itemDiameterForBounds = 0, bool $centerXOnly = false): array
    {
        if (empty($items)) return [];
        $this->addLog("DEBUG", "_alignLoadCenter: Centralizando " . count($items) . " itens. CenterXOnly: " . ($centerXOnly ? 'true':'false'));
        $min_x_overall = PHP_FLOAT_MAX; $max_x_overall = -PHP_FLOAT_MAX; 
        $min_y_overall = PHP_FLOAT_MAX; $max_y_overall = -PHP_FLOAT_MAX; 
        foreach ($items as $item) {
            $min_x_overall = min($min_x_overall, $item['x']); $max_x_overall = max($max_x_overall, $item['x'] + $item['w']);
            $min_y_overall = min($min_y_overall, $item['y']); $max_y_overall = max($max_y_overall, $item['y'] + $item['d']);
        }
        if ($min_x_overall === PHP_FLOAT_MAX || $max_x_overall === -PHP_FLOAT_MAX ) { 
            $this->addLog("WARNING", "_alignLoadCenter: Não foi possível calcular os limites da carga."); return $items;
        }
        $centro_carga_x = ($min_x_overall + $max_x_overall) / 2;
        $offset_x = ($containerW / 2) - $centro_carga_x;
        $offset_y = 0; 
        if (!$centerXOnly) {
            $centro_carga_y = ($min_y_overall + $max_y_overall) / 2;
            $offset_y = ($containerD / 2) - $centro_carga_y;
        }
        $this->addLog("DEBUG", "_alignLoadCenter: Offset X={$offset_x}, Offset Y={$offset_y}");
        $alignedItems = [];
        foreach ($items as $item) {
            $newItem = $item; $newItem['x'] += $offset_x; $newItem['y'] += $offset_y; 
            if ($newItem['x'] < -1e-6 || ($newItem['x'] + $newItem['w']) > $containerW + 1e-6 ||
                $newItem['y'] < -1e-6 || ($newItem['y'] + $newItem['d']) > $containerD + 1e-6) {
                $this->addLog("WARNING", "_alignLoadCenter: Item Inst.ID ".$newItem['id_original_instance']." pode ter ficado fora dos limites. X:".$newItem['x'].", Y:".$newItem['y']);
            }
            $alignedItems[] = $newItem;
        } return $alignedItems;
    }
    
    private function _standardPackingAlgorithm(float $W_cont, float $D_cont, float $H_cont, array $itemsToPackInput, array $existingPlacedItems = []): array
    {
        $this->addLog("INFO", "Iniciando algoritmo de empacotamento padrão/height-map para " . count($itemsToPackInput) . " itens novos.");
        $placedItemsFromStdAlg = []; $packedCountStd = 0;
        $placedItemsSnapshot = $existingPlacedItems; 
        $this->lastPlacedItemDetails = empty($existingPlacedItems) ? null : end($existingPlacedItems);
        $itemsToPack = $itemsToPackInput; 
        if ($this->sortByVolumeDesc && !empty($itemsToPack)) { 
            usort($itemsToPack, function($a, $b) { $volA_d = ($a['tipo'] === 'bobina') ? $a['w_orig'] : $a['d_orig']; $volB_d = ($b['tipo'] === 'bobina') ? $b['w_orig'] : $b['d_orig']; $volA = $a['w_orig'] * $volA_d * $a['h_orig']; $volB = $b['w_orig'] * $volB_d * $b['h_orig']; if (abs($volA - $volB) < 1e-6) return 0; return ($volA > $volB) ? -1 : 1; });
            $this->addLog("INFO", "(Padrão) Itens ordenados por volume.");
        } elseif (!empty($itemsToPack)) { $this->addLog("INFO", "(Padrão) Empacotando na ordem de entrada."); }
        $candidatePositions = [[0.0, 0.0]];
        foreach($placedItemsSnapshot as $pi) {
            if ($pi['x'] + $pi['w'] < $W_cont - 1e-6) $candidatePositions[] = [$pi['x'] + $pi['w'], $pi['y']];
            if ($pi['y'] + $pi['d'] < $D_cont - 1e-6) $candidatePositions[] = [$pi['x'], $pi['y'] + $pi['d']];
        }
        if(!empty($placedItemsSnapshot) || empty($candidatePositions)) $candidatePositions[] = [0.0,0.0]; 
        $candidatePositions = array_map('unserialize', array_unique(array_map('serialize', $candidatePositions)));
        usort($candidatePositions, function($a, $b){ if(abs($a[1] - $b[1]) > 1e-6) return ($a[1] < $b[1]) ? -1 : 1; if(abs($a[0] - $b[0]) > 1e-6) return ($a[0] < $b[0]) ? -1 : 1; return 0; });
        $computeSupportHeight = function($xPos, $yPos, $wItem, $dItem) use (&$placedItemsSnapshot) { $supportZ = 0.0; foreach ($placedItemsSnapshot as $pi) { if (!($xPos + $wItem <= $pi['x'] + 1e-6 || $pi['x'] + $pi['w'] <= $xPos + 1e-6) && !($yPos + $dItem <= $pi['y'] + 1e-6 || $pi['y'] + $pi['d'] <= $yPos + 1e-6)) { $supportZ = max($supportZ, $pi['z'] + $pi['h']); } } return $supportZ; };
        $totalItemsForStdAlg = count($itemsToPack);
        if($totalItemsForStdAlg == 0) { if (empty($existingPlacedItems)) $this->addLog("INFO", "(Padrão) Nenhum item."); else $this->addLog("INFO", "(Padrão) Nenhum item NOVO."); return [0, []]; }
        
        foreach ($itemsToPack as $item_idx => $itemOriginalInstance) { 
            $idInstance = $itemOriginalInstance['id_original_instance']; $tipoOriginalItem = $itemOriginalInstance['tipo'];
            $itemIdentifier = "Inst.ID {$idInstance} (GrupoID: ".($itemOriginalInstance['id_grupo_item']??'N/A').", {$tipoOriginalItem} orig: {$itemOriginalInstance['w_orig']}×{$itemOriginalInstance['d_orig']}×{$itemOriginalInstance['h_orig']})";
            $this->addLog("DEBUG", "(Padrão) Processando item ".($item_idx+1)."/".$totalItemsForStdAlg.": {$itemIdentifier}. Candidatas: " . count($candidatePositions));
            $bestPlacementOverallForThisInstance = null; $allPossiblePlacementsForThisInstance = []; 
            $orientations = $this->getItemOrientations($itemOriginalInstance); 
            
            foreach ($orientations as $orientedItem) { 
                $w_oriented = $orientedItem['w']; $d_oriented = $orientedItem['d']; $h_oriented = $orientedItem['h'];
                if (!$this->sortByVolumeDesc && $this->allow_stacking && $this->lastPlacedItemDetails) { 
                    $prevItem = $this->lastPlacedItemDetails; 
                    if ($prevItem['tipo'] === $tipoOriginalItem && abs($w_oriented - $prevItem['w']) < 1e-6 && abs($d_oriented - $prevItem['d']) < 1e-6) {
                        $cx_stack = $prevItem['x']; $cy_stack = $prevItem['y']; $zBaseForStack = $prevItem['z'] + $prevItem['h'];
                        if ($zBaseForStack + $h_oriented <= $H_cont + 1e-6) {
                            if (abs($computeSupportHeight($cx_stack, $cy_stack, $w_oriented, $d_oriented) - $zBaseForStack) < 1e-6) {
                                $allPossiblePlacementsForThisInstance[] = [ 'x' => $cx_stack, 'y' => $cy_stack, 'z_base' => $zBaseForStack, 'w' => $w_oriented, 'd' => $d_oriented, 'h' => $h_oriented, 'tipo_original_item' => $tipoOriginalItem, 'id_original_instance' => $idInstance, 'id_grupo_item' => $orientedItem['id_grupo_item'], 'peso_bruto_orig' => $itemOriginalInstance['peso_bruto_orig'], 'is_preferred_stack' => true ];
                }}}}
                foreach ($candidatePositions as $candPos) { 
                    list($cx, $cy) = $candPos;
                    if ($cx + $w_oriented > $W_cont + 1e-6 || $cy + $d_oriented > $D_cont + 1e-6) continue;
                    $zBaseCalculated = $computeSupportHeight($cx, $cy, $w_oriented, $d_oriented);
                    $zBaseToUse = $zBaseCalculated;
                    if (!$this->allow_stacking) { if ($zBaseCalculated > 1e-6) continue; $zBaseToUse = 0.0; }
                    if ($zBaseToUse + $h_oriented > $H_cont + 1e-6) continue; 
                    $allPossiblePlacementsForThisInstance[] = [ 'x' => $cx, 'y' => $cy, 'z_base' => $zBaseToUse, 'w' => $w_oriented, 'd' => $d_oriented, 'h' => $h_oriented, 'tipo_original_item' => $tipoOriginalItem, 'id_original_instance' => $idInstance, 'id_grupo_item' => $orientedItem['id_grupo_item'], 'peso_bruto_orig' => $itemOriginalInstance['peso_bruto_orig'], 'is_preferred_stack' => false ];
                }}
            if (!empty($allPossiblePlacementsForThisInstance)) {
                $allPossiblePlacementsForThisInstance = array_map("unserialize", array_unique(array_map("serialize", $allPossiblePlacementsForThisInstance)));
                $isOrderedLoading = !$this->sortByVolumeDesc; $lastItemDetailsForSort = $this->lastPlacedItemDetails;
                // A alteração foi a remoção do comentário que estava aqui na linha abaixo:
                usort($allPossiblePlacementsForThisInstance, function($a, $b) use ($isOrderedLoading, $lastItemDetailsForSort) { 
                    if ($isOrderedLoading && $lastItemDetailsForSort !== null) {
                        $a_is_preferred_stack_on_last = ($a['is_preferred_stack'] && $a['tipo_original_item'] === $lastItemDetailsForSort['tipo'] && abs($a['w'] - $lastItemDetailsForSort['w']) < 1e-6 && abs($a['d'] - $lastItemDetailsForSort['d']) < 1e-6 && abs($a['x'] - $lastItemDetailsForSort['x']) < 1e-6 && abs($a['y'] - $lastItemDetailsForSort['y']) < 1e-6 && abs($a['z_base'] - ($lastItemDetailsForSort['z'] + $lastItemDetailsForSort['h'])) < 1e-6);
                        $b_is_preferred_stack_on_last = ($b['is_preferred_stack'] && $b['tipo_original_item'] === $lastItemDetailsForSort['tipo'] && abs($b['w'] - $lastItemDetailsForSort['w']) < 1e-6 && abs($b['d'] - $lastItemDetailsForSort['d']) < 1e-6 && abs($b['x'] - $lastItemDetailsForSort['x']) < 1e-6 && abs($b['y'] - $lastItemDetailsForSort['y']) < 1e-6 && abs($b['z_base'] - ($lastItemDetailsForSort['z'] + $lastItemDetailsForSort['h'])) < 1e-6);
                        if ($a_is_preferred_stack_on_last && !$b_is_preferred_stack_on_last) return -1; 
                        if (!$a_is_preferred_stack_on_last && $b_is_preferred_stack_on_last) return 1;  
                    }
                    if (abs($a['z_base'] - $b['z_base']) > 1e-6) return ($a['z_base'] < $b['z_base']) ? -1 : 1;
                    if (abs($a['y'] - $b['y']) > 1e-6) return ($a['y'] < $b['y']) ? -1 : 1;
                    if (abs($a['x'] - $b['x']) > 1e-6) return ($a['x'] < $b['x']) ? -1 : 1; return 0;
                });
                $bestPlacementOverallForThisInstance = $allPossiblePlacementsForThisInstance[0]; 
            }
            if ($bestPlacementOverallForThisInstance !== null) {
                $finalPlacementData = $bestPlacementOverallForThisInstance;
                $currentPlacedItem = [ 
                    'x' => $finalPlacementData['x'], 'y' => $finalPlacementData['y'], 'z' => $finalPlacementData['z_base'], 
                    'w' => $finalPlacementData['w'], 'd' => $finalPlacementData['d'], 'h' => $finalPlacementData['h'], 
                    'tipo' => $finalPlacementData['tipo_original_item'], 
                    'id_original_instance' => $finalPlacementData['id_original_instance'],
                    'id_grupo_item' => $finalPlacementData['id_grupo_item'], 
                    'peso_bruto' => $finalPlacementData['peso_bruto_orig'] 
                ];
                $isValidForPlacement = true; $validationErrorMsg = "";
                if (!is_numeric($currentPlacedItem['x']) || !is_numeric($currentPlacedItem['y']) || !is_numeric($currentPlacedItem['z'])) { $isValidForPlacement = false; $validationErrorMsg .= "Posição não numérica. "; }
                if (!is_numeric($currentPlacedItem['w']) || $currentPlacedItem['w'] <= 1e-7 || !is_numeric($currentPlacedItem['d']) || $currentPlacedItem['d'] <= 1e-7 || !is_numeric($currentPlacedItem['h']) || $currentPlacedItem['h'] <= 1e-7) { $isValidForPlacement = false; $validationErrorMsg .= "Dimensões inválidas. "; }
                if (!in_array($currentPlacedItem['tipo'], ['caixa', 'bobina'])) { $isValidForPlacement = false; $validationErrorMsg .= "Tipo inválido. ";}
                if ($isValidForPlacement) {
                    $placedItemsFromStdAlg[] = $currentPlacedItem; $placedItemsSnapshot[] = $currentPlacedItem; $packedCountStd++; 
                    if (!$this->sortByVolumeDesc) { $this->lastPlacedItemDetails = $currentPlacedItem; } else { $this->lastPlacedItemDetails = null; }
                    $newCand_X = [$currentPlacedItem['x'] + $currentPlacedItem['w'], $currentPlacedItem['y']];
                    $newCand_Y = [$currentPlacedItem['x'], $currentPlacedItem['y'] + $currentPlacedItem['d']];
                    $candidatePositions[] = [$currentPlacedItem['x'], $currentPlacedItem['y']]; 
                    if ($newCand_X[0] < $W_cont - 1e-6) $candidatePositions[] = $newCand_X;
                    if ($newCand_Y[1] < $D_cont - 1e-6) $candidatePositions[] = $newCand_Y;
                    $logMsg = "(Padrão) {$itemIdentifier} POSICIONADO..."; $this->addLog("INFO", $logMsg);
                } else { $this->addLog("ERROR", "(Padrão) DADOS INVÁLIDOS para {$itemIdentifier}, IGNORADO. Erro: {$validationErrorMsg}"); if (!$this->sortByVolumeDesc) { $this->lastPlacedItemDetails = null; }}
            } else { $this->addLog("WARNING", "(Padrão) Sem espaço: {$itemIdentifier}."); if (!$this->sortByVolumeDesc) { $this->lastPlacedItemDetails = null; }}
            $candidatePositions = array_map('unserialize', array_unique(array_map('serialize', $candidatePositions)));
            usort($candidatePositions, function($a, $b){ if(abs($a[1] - $b[1]) > 1e-6) return ($a[1] < $b[1]) ? -1 : 1; if(abs($a[0] - $b[0]) > 1e-6) return ($a[0] < $b[0]) ? -1 : 1; return 0; });
        } return [$packedCountStd, $placedItemsFromStdAlg];
    }

    public function getPlacedItemsVolume(): float { 
        $totalVolumeItems = 0.0; foreach ($this->placedItems as $item) { $item_vol = 0.0; $item_w = $item['w'] ?? 0.0; $item_d = $item['d'] ?? 0.0; $item_h = $item['h'] ?? 0.0; $item_tipo = $item['tipo'] ?? 'desconhecido'; if (is_numeric($item_w) && is_numeric($item_d) && is_numeric($item_h)) { if (strtolower($item_tipo) === 'bobina' && $item_w > 1e-6 && $item_h > 1e-6) { $radius = $item_w / 2.0; $item_vol = M_PI * $radius * $radius * $item_h; } elseif (strtolower($item_tipo) === 'caixa' && $item_w > 1e-6 && $item_d > 1e-6 && $item_h > 1e-6) { $item_vol = $item_w * $item_d * $item_h; } } $totalVolumeItems += $item_vol; } return (float)$totalVolumeItems; 
    }
    public function getVolumeUtilization(): float { 
        $containerVolume = $this->W * $this->D * $this->H; if (abs($containerVolume) < 1e-6) return 0.0; $placedVolume = $this->getPlacedItemsVolume(); return ($placedVolume / $containerVolume) * 100.0;
    }
    public function getPlacedItemsWeight(): float { 
        $totalWeightItems = 0.0; foreach ($this->placedItems as $item) { $item_peso = $item['peso_bruto'] ?? 0.0; if (is_numeric($item_peso)) { $totalWeightItems += (float)$item_peso; } } return (float)$totalWeightItems;
    }
    public function getPlacedItems(): array { return $this->placedItems; }
}